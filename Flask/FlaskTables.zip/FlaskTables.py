from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def main():
    if request.method == 'GET':
        return render_template('FlaskTableInput.html')
    else:
        return GetInfo()

def GetInfo():
    pd1 = request.form.get('txtpd1')
    pd2 = request.form.get('txtpd2')
    pd3 = request.form.get('txtpd3')
    pd4 = request.form.get('txtpd4')
    pd5 = request.form.get('txtpd5')
    pd6 = request.form.get('txtpd6')
    pd7 = request.form.get('txtpd7')
    pd8 = request.form.get('txtpd8')
    return display(pd1, pd2, pd3, pd4, pd5, pd6, pd7, pd8)

def display(pd1, pd2, pd3, pd4, pd5, pd6, pd7, pd8):
    return render_template('FlaskTablesOut.html',pd1=pd1,pd2=pd2,pd3=pd3,pd4=pd4,pd5=pd5,pd6=pd6,pd7=pd7,pd8=pd8)

if __name__ == "__main__":
    app.run()
