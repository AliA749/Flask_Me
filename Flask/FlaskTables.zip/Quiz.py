'''
Sudhir Sukhai
03/26/2024
description: A basic quiz
'''
from flask import Flask,render_template,request

app = Flask(__name__)

@app.route("/",methods=['GET','POST'])
def main():
    if request.method == 'GET':
        return render_template('Test.html')
    else:
        return GetInfo()

def GetInfo():
    In1 = request.form.get('txtnum1')
    In2 = request.form.get('txtnum2')
    #total
    total = int(In1)+int(In2)
    return render_template("QuizDisp.html",total=total)



if __name__ == "__main__":
    app.run()
