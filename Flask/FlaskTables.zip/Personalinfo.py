'''
Sudhir Sukhai
03/07/2024
description: A basic flask transferring program
'''

from flask import Flask,render_template,request

app = Flask(__name__)

@app.route("/",methods=['GET','POST'])
def main():
    if request.method == 'GET':
        return render_template('GradePlus.html')
    else:
        return GetInfo()

def GetInfo():
    global headings,data
    headings=("Course","Room","Teacher","Grade")
    #classes
    CL1 = request.form.get('txtCl1')
    CL2 = request.form.get('txtCl2')
    CL3 = request.form.get('txtCl3')
    CL4 = request.form.get('txtCl4')
    CL5 = request.form.get('txtCl5')
    CL6 = request.form.get('txtCl6')
    CL7 = request.form.get('txtCl7')
    CL8 = request.form.get('txtCl8')
    CL9 = request.form.get('txtCl9')
    #Room nums
    Rm1 = request.form.get('txtRm1')
    Rm2 = request.form.get('txtRm2')
    Rm3 = request.form.get('txtRm3')
    Rm4 = request.form.get('txtRm4')
    Rm5 = request.form.get('txtRm5')
    Rm6 = request.form.get('txtRm6')
    Rm7 = request.form.get('txtRm7')
    Rm8 = request.form.get('txtRm8')
    Rm9 = request.form.get('txtRm9')
    #Teachers
    Te1 = request.form.get('txtTe1')
    Te2 = request.form.get('txtTe2')
    Te3 = request.form.get('txtTe3')
    Te4 = request.form.get('txtTe4')
    Te5 = request.form.get('txtTe5')
    Te6 = request.form.get('txtTe6')
    Te7 = request.form.get('txtTe7')
    Te8 = request.form.get('txtTe8')
    #Grades
    Gr1 = request.form.get('txtGr1')
    Gr2 = request.form.get('txtGr2')
    Gr3 = request.form.get('txtGr3')
    Gr4 = request.form.get('txtGr4')
    Gr5 = request.form.get('txtGr5')
    Gr6 = request.form.get('txtGr6')
    Gr7 = request.form.get('txtGr7')
    Gr8 = request.form.get('txtGr8')
    total = int(Gr1)+int(Gr2)+int(Gr3)+int(Gr4)+int(Gr5)+int(Gr6)+int(Gr7)+int(Gr8)
    Avg= str(int(total)/8)
    data=(
        (CL1,Rm1,Te1,Gr1),
        (CL2,Rm2,Te2,Gr2),
        (CL3,Rm3,Te3,Gr3),
        (CL4,Rm4,Te4,Gr4),
        (CL5,Rm5,Te5,Gr5),
        (CL6,Rm6,Te6,Gr6),
        (CL7,Rm7,Te7,Gr7),
        (CL8,Rm8,Te8,Gr8),
        ("Your","average","is",Avg)
        )
    return DisplayInfo()

def DisplayInfo():
    return render_template("personalinfo.html",headings=headings,data=data)

    
if __name__ == "__main__":
    app.run()
