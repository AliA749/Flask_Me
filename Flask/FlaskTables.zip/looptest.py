'''
Sudhir Sukhai
03/26/2024
description: A basic quiz
'''
from flask import Flask,render_template,request

app = Flask(__name__)


@app.route("/",methods=['GET','POST'])

def main():
    mylist=[]
    mylist=["Math","Science","English","History","Software Engineering"]
    mylistlen=len(mylist)
    return render_template("forloopintro.html",mylistlen=mylistlen, mylist=mylist)



if __name__ == "__main__":
    app.run()
